/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Circle.h
 * Author: paubc
 *
 * Created on 27 / de febrer / 2018, 18:58
 */
#ifndef CIRCLE_H
#define CIRCLE_H


class Circle : public Ellipse{


public:
        
    Circle();

    
    
    
};


#endif /* CIRCLE_H */

